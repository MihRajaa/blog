# Acme Demo

## Installation

Copy the extension to phpBB/ext/acme/demo

Go to "ACP" > "Customise" > "Extensions" and enable the "Acme Demo" extension.

## License

[GNU General Public License v2](license.txt)
